from __future__ import print_function
import requests
import time
import datetime
from googleapiclient.discovery import build
import database as db
import google.oauth2.credentials
from google.oauth2.credentials import Credentials
import quickstart as api
goog_url = 'https://www.googleapis.com/oauth2/v4/token'

# If modifying these scopes, delete the file token.json.
SCOPES = ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive.metadata.readonly']

def main(user_id):
    """Shows basic usage of the Drive v3 API.
    Prints the names and ids of the first 10 files the user has access to.
    """
    creds = db.query_google_token(user_id)
    expires = creds['expires_at']
    # If there are no (valid) credentials available, let the user log in.
    if creds['expires_at'].timestamp() < time.time():
        res = requests.post(
            url=goog_url,
            data={
                'client_id': '882547647274-nfh6efs7c3q69r67fhtjkonm8o4b15ia.apps.googleusercontent.com',
                'client_secret': 'Rm4v_Gt1yTe9ZSpD5AX1VONS',
                'grant_type': 'refresh_token',
                'refresh_token': creds['refresh_token'],
                'access_type': 'offline',
                'prompt': 'consent'
            }
        )
        creds['token'] = res.json()['access_token']
        expires = datetime.datetime.fromtimestamp(time.time() + res.json()['expires_in'])
        db.update_google_token(user_id, creds)

    creds['token_uri'] = "https://oauth2.googleapis.com/token"
    creds['client_id'] = '882547647274-nfh6efs7c3q69r67fhtjkonm8o4b15ia.apps.googleusercontent.com'
    creds['client_secret'] = 'Rm4v_Gt1yTe9ZSpD5AX1VONS'
    creds['scopes'] = SCOPES
    credentials = google.oauth2.credentials.Credentials(token=creds['token'],
                                                        refresh_token=creds['refresh_token'],
                                                        token_uri=creds['token_uri'],
                                                        client_id=creds['client_id'],
                                                        client_secret=creds['client_secret'],
                                                        scopes=SCOPES)
    service = build('drive', 'v3', credentials=credentials)
    creds['expires_at'] = expires

    # Store credentials in DB again
    db.update_google_token(user_id, creds)

    # Call the Drive v3 API
    results = service.files().list(
        q="mimeType='application/vnd.google-apps.spreadsheet'",
        pageSize=15, fields="nextPageToken, files(id, name)").execute()
    items = results.get('files', [])

    if not items:
        print('No files found.')
    else:
        files = []
        print('Files:')
        for item in items:
            print(u'{0} ({1})'.format(item['name'], item['id']))
            files.append([item['name'], item['id']])
    return files

if __name__ == '__main__':
    main(45934359)